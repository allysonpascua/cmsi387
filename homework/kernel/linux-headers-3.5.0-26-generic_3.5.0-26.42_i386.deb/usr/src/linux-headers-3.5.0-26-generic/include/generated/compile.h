/* This file is auto generated, version 42 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#42 SMP Sat Mar 9 23:44:31 PST 2013"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "allyson-VirtualBox"
#define LINUX_COMPILER "gcc version 4.7.2 (Ubuntu/Linaro 4.7.2-2ubuntu1) "
